<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2021</span>
        </div>
    </div>
</footer><?php /**PATH D:\Sistem-Informasi-Manajemen-Sekolah\resources\views/layouts/footer_new.blade.php ENDPATH**/ ?>