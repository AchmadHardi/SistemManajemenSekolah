
<?php $__env->startSection('title', 'Restore Siswa'); ?>
<?php $__env->startSection('contents'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3>Restore Siswa</h3>
            </div>
            <div class="card-body">
                <?php if($trashedSiswa->count() > 0): ?>
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NIS</th>
                                <th>Nama</th>
                                <th>Jenis Kelamin</th>
                                <th>Alamat</th>
                                <th>Profile</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $trashedSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->nis); ?></td>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->jk); ?></td>
                                    <td><?php echo e($item->alamat); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('storage/assets/car/' . $item->gambar)); ?>" width="100">
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('siswa.restore', $item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button type="submit" class="btn btn-success btn-sm">Restore</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Tidak ada data siswa yang dapat dipulihkan.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sistem-Informasi-Manajemen-Sekolah\resources\views/siswa/trash.blade.php ENDPATH**/ ?>