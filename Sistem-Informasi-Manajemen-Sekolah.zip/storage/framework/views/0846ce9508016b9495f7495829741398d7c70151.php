
<?php $__env->startSection('title', 'Data Guru'); ?>
<?php $__env->startSection('contents'); ?>
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <div class="row justify-content-between align-items-center">
            <div class="col-auto">
             
            </div>
            <div class="col-auto">
              <a href="<?php echo e(route('pdf', ['param' => 'guru', 'download' => 1])); ?>" target="_blank" class="btn btn-sm btn-warning"><i class="bi bi-download"></i> Download PDF</a>
              <a href="<?php echo e(route('pdf', ['param' => 'guru'])); ?>" target="_blank" class="btn btn-sm btn-success"><i class="bi bi-printer"></i> Cetak PDF</a>
              <a href="<?php echo e(route('guru.create')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-person-plus"></i> Tambah Data Guru</a>
            </div>
          </div>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-hover align-middle">
              <thead>
                <tr>
                  <th class="text-center" scope="col" style="width: 75px">No</th>
                  <th scope="col">NIP</th>
                  <th scope="col">Nama</th>
                  <th scope="col">Jenis Kelamin</th>
                  <th scope="col">Alamat</th>
                  <th class="text-center" scope="col" style="width: 125px">Aksi</th>
                </tr>
              </thead>
              <tbody class="table-group-divider">
                <?php
                  $no = 1;
                ?>
                <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th class="text-center" scope="row"><?php echo e($no++); ?></th>
                    <td><?php echo e($item->nip); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><?php echo e($item->jk); ?></td>
                    <td><?php echo e($item->alamat); ?></td>
                    <td class="text-center">
                      <div class="btn-group">
                        <a href="<?php echo e(route('guru.update', $item->id)); ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil-square"></i></a>
                        <a href="<?php echo e(route('guru.destroy', $item->id)); ?>" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></a>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_new' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sistem-Informasi-Manajemen-Sekolah\resources\views/guru/index.blade.php ENDPATH**/ ?>