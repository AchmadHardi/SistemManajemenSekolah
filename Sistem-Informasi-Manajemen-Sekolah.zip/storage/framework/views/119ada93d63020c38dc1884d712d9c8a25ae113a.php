
<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('contents'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="row justify-content-between align-items-center">
                    <div class="col-auto">
                        <form action="" method="get">
                            <div class="input-group mt-3">
                                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                                    class="form-control bg-light border-0 small" placeholder="Search for..."
                                    aria-label="Search" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary ml-1" type="button">
                                        <i class="fas fa-search fa-sm"></i>
                                    </button>
                                </div>
                                <?php if(session()->has('message')): ?>
                                    <div class="alert alert-<?php echo e(session('alert-info')); ?> mt-3">
                                        <?php echo e(session('message')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                    <div class="col-auto">
                        <a href="<?php echo e(route('pdf', ['param' => 'siswa', 'download' => 1])); ?>" target="_blank"
                            class="btn btn-sm btn-warning"><i class="bi bi-download"></i> Download PDF</a>
                        <a href="<?php echo e(route('pdf', ['param' => 'siswa'])); ?>" target="_blank" class="btn btn-sm btn-success"><i
                                class="bi bi-printer"></i> Cetak PDF</a>
                        <a href="<?php echo e(route('siswa.create')); ?>" class="btn btn-sm btn-primary"><i
                                class="bi bi-person-plus"></i> Tambah Data Siswa</a>
                        <a href="<?php echo e(route('siswa.trash')); ?>" class="btn btn-sm btn-primary"><i
                                class="fas fa-trash-restore"></i> Recovery</a>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="modal fade" id="hapus_siswa<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><span
                                        class="text-danger"><b>PERINGATAN!</b></span>
                                </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('siswa.destroy', $item->id)); ?>" method="delete">
                                    <?php echo csrf_field(); ?>
                                    
                                    <p>Yakin ingin menghapus data <b style="color: red"><?php echo e($item->nama); ?></b> ?</p>
                                    <hr>
                                    <button class="btn btn-danger float-right">Hapus</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th class="text-center" scope="col" style="width: 75px">No</th>
                                <th scope="col">NIS</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Jenis Kelamin</th>
                                <th scope="col">Alamat</th>
                                <th scope="col">Profile</th>
                                <th class="text-center" scope="col" style="width: 125px">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="table-group-divider">

                            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="text-center" scope="row"><?php echo e($siswa->firstItem() + $key); ?></th>
                                    <td><?php echo e($item->nis); ?></td>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->jk); ?></td>
                                    <td><?php echo e($item->alamat); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('storage/assets/car/' . $item->gambar)); ?>" width="100">
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('siswa.update', $item->id)); ?>"
                                                class="btn btn-sm btn-outline-warning"><i
                                                    class="bi bi-pencil-square"></i></a>
                                            <button type="button" class="btn btn-danger btn-sm shadow-sm mr-1 delete-data"
                                                data-toggle="modal" data-target="#hapus_siswa<?php echo e($item->id); ?>"
                                                title="Hapus"><i class="fas fa-trash-alt"></i></button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php echo e($siswa->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sistem-Informasi-Manajemen-Sekolah\resources\views/siswa/index.blade.php ENDPATH**/ ?>